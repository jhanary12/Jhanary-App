package com.example.rentmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlin.random.Random

// --- DATA MODELS ---

data class Room(
    val id: String = UUID.randomUUID().toString(),
    val name: String
)

data class PaymentRecord(
    val id: String = UUID.randomUUID().toString(),
    val roomId: String,
    val date: Date,
    val rentAmount: Double,
    val waterAmount: Double,
    val electricAmount: Double
) {
    val total: Double get() = rentAmount + waterAmount + electricAmount
}

// --- VIEW MODEL (Logic & State) ---

class PropertyViewModel : ViewModel() {
    // In a real app, these would be loaded from a Room Database or FireStore
    private val _rooms = mutableStateListOf<Room>()
    val rooms: List<Room> get() = _rooms

    private val _records = mutableStateListOf<PaymentRecord>()
    val records: List<PaymentRecord> get() = _records

    // Initial dummy data for demonstration
    init {
        _rooms.add(Room(name = "Room 101"))
        _rooms.add(Room(name = "Room 102"))

        // Add some records for the current month
        _records.add(PaymentRecord(roomId = _rooms[0].id, date = Date(), rentAmount = 500.0, waterAmount = 20.0, electricAmount = 50.0))
    }

    fun addRoom(name: String) {
        _rooms.add(Room(name = name))
    }

    fun addRecord(roomId: String, rent: Double, water: Double, electric: Double) {
        _records.add(
            PaymentRecord(
                roomId = roomId,
                date = Date(), // Defaults to 'now'
                rentAmount = rent,
                waterAmount = water,
                electricAmount = electric
            )
        )
    }

    fun getRecordsForRoom(roomId: String): List<PaymentRecord> {
        return _records.filter { it.roomId == roomId }.sortedByDescending { it.date }
    }

    // --- Stats Logic ---

    fun getCurrentMonthTotal(): Double {
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        return _records.filter {
            val recordCal = Calendar.getInstance().apply { time = it.date }
            recordCal.get(Calendar.MONTH) == currentMonth && recordCal.get(Calendar.YEAR) == currentYear
        }.sumOf { it.total }
    }

    fun getCurrentYearTotal(): Double {
        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)

        return _records.filter {
            val recordCal = Calendar.getInstance().apply { time = it.date }
            recordCal.get(Calendar.YEAR) == currentYear
        }.sumOf { it.total }
    }
}

// --- MAIN ACTIVITY ---

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RentManagerApp()
                }
            }
        }
    }
}

// --- SCREENS & NAVIGATION ---

enum class Screen { Dashboard, RoomDetails }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RentManagerApp(viewModel: PropertyViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(Screen.Dashboard) }
    var selectedRoom by remember { mutableStateOf<Room?>(null) }
    var showAddRoomDialog by remember { mutableStateOf(false) }
    var showAddRecordDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(text = if (currentScreen == Screen.Dashboard) "Rent Manager" else selectedRoom?.name ?: "Details")
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                navigationIcon = {
                    if (currentScreen == Screen.RoomDetails) {
                        IconButton(onClick = { currentScreen = Screen.Dashboard }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (currentScreen == Screen.Dashboard) {
                        showAddRoomDialog = true
                    } else {
                        showAddRecordDialog = true
                    }
                }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            if (currentScreen == Screen.Dashboard) {
                DashboardScreen(
                    viewModel = viewModel,
                    onRoomClick = { room ->
                        selectedRoom = room
                        currentScreen = Screen.RoomDetails
                    }
                )
            } else {
                selectedRoom?.let { room ->
                    RoomDetailScreen(
                        room = room,
                        viewModel = viewModel
                    )
                }
            }
        }

        // Dialogs
        if (showAddRoomDialog) {
            AddRoomDialog(
                onDismiss = { showAddRoomDialog = false },
                onConfirm = { name ->
                    viewModel.addRoom(name)
                    showAddRoomDialog = false
                }
            )
        }

        if (showAddRecordDialog && selectedRoom != null) {
            AddRecordDialog(
                roomName = selectedRoom!!.name,
                onDismiss = { showAddRecordDialog = false },
                onConfirm = { rent, water, electric ->
                    viewModel.addRecord(selectedRoom!!.id, rent, water, electric)
                    showAddRecordDialog = false
                }
            )
        }
    }
}

// --- DASHBOARD ---

@Composable
fun DashboardScreen(
    viewModel: PropertyViewModel,
    onRoomClick: (Room) -> Unit
) {
    Column(modifier = Modifier.padding(16.dp)) {
        // Stats Section
        Text(
            "Financial Overview",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatsCard(
                title = "This Month",
                amount = viewModel.getCurrentMonthTotal(),
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.primaryContainer
            )
            StatsCard(
                title = "This Year",
                amount = viewModel.getCurrentYearTotal(),
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.secondaryContainer
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Rooms List
        Text(
            "Rooms",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(viewModel.rooms) { room ->
                RoomCard(room = room, onClick = { onRoomClick(room) })
            }
        }
    }
}

@Composable
fun StatsCard(title: String, amount: Double, modifier: Modifier = Modifier, color: Color) {
    val format = NumberFormat.getCurrencyInstance(Locale.US)
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelMedium)
            Text(
                text = format.format(amount),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun RoomCard(room: Room, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Home, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = room.name, style = MaterialTheme.typography.titleMedium)
        }
    }
}

// --- ROOM DETAILS ---

@Composable
fun RoomDetailScreen(room: Room, viewModel: PropertyViewModel) {
    val records = viewModel.getRecordsForRoom(room.id)
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val currencyFormat = NumberFormat.getCurrencyInstance(Locale.US)

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "Payment History",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (records.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No records found. Add one!", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { record ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = dateFormat.format(record.date),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = currencyFormat.format(record.total),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Divider(modifier = Modifier.padding(vertical = 8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Rent", style = MaterialTheme.typography.labelSmall)
                                    Text(currencyFormat.format(record.rentAmount))
                                }
                                Column {
                                    Text("Water", style = MaterialTheme.typography.labelSmall)
                                    Text(currencyFormat.format(record.waterAmount))
                                }
                                Column {
                                    Text("Electric", style = MaterialTheme.typography.labelSmall)
                                    Text(currencyFormat.format(record.electricAmount))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- DIALOGS ---

@Composable
fun AddRoomDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var roomName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Add New Room", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = roomName,
                    onValueChange = { roomName = it },
                    label = { Text("Room Name/Number") },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { if(roomName.isNotBlank()) onConfirm(roomName) }) { Text("Add") }
                }
            }
        }
    }
}

@Composable
fun AddRecordDialog(
    roomName: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, Double, Double) -> Unit
) {
    var rent by remember { mutableStateOf("") }
    var water by remember { mutableStateOf("") }
    var electric by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Add Record", style = MaterialTheme.typography.titleLarge)
                Text("For $roomName", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = rent,
                    onValueChange = { if(it.all { char -> char.isDigit() || char == '.' }) rent = it },
                    label = { Text("Rent Amount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = water,
                    onValueChange = { if(it.all { char -> char.isDigit() || char == '.' }) water = it },
                    label = { Text("Water Bill") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = electric,
                    onValueChange = { if(it.all { char -> char.isDigit() || char == '.' }) electric = it },
                    label = { Text("Electric Bill") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) }, // Placeholder icon
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(24.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = {
                        val r = rent.toDoubleOrNull() ?: 0.0
                        val w = water.toDoubleOrNull() ?: 0.0
                        val e = electric.toDoubleOrNull() ?: 0.0
                        onConfirm(r, w, e)
                    }) { Text("Save") }
                }
            }
        }
    }
}
class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "Refreshed token: $token")
        // In a real app, send this token to your server to target this specific user
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        // Check if message contains a notification payload.
        remoteMessage.notification?.let {
            sendNotification(it.title ?: "Rent Manager", it.body ?: "Check your app")
        }
    }

    private fun sendNotification(title: String, messageBody: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = "rent_reminders"
        val defaultSoundUri = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Use your own icon here
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Rent Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(Random.nextInt(), notificationBuilder.build())
    }
}
